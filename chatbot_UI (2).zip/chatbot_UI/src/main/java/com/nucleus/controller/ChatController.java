package com.nucleus.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.models.TilesModel;

@RestController

public class ChatController {

	@RequestMapping("/")
	public ModelAndView handler() {
		System.out.println("in req1");
		ModelAndView mv = new ModelAndView("index");
		return mv;
	}

	@RequestMapping("/getResponse")
	@ResponseBody
	public String getResponse(@RequestParam(value = "requestText", required = true) String requestText) {
		JSONObject responseObj = new JSONObject();
		System.out.println("reqText:"+requestText);
		if (requestText.contains("fetchListData")) {
			List<String> valueList = new ArrayList<String>();
			valueList.add("Option 1");
			valueList.add("Option 2");
			valueList.add("Option 3");
			responseObj.put("responseMsg", "Select one of the following : ");

			responseObj.put("responseData", valueList);
			responseObj.put("responseType", "buttons");

		} else if (requestText.contains("fetchTilesData")) {
			List<TilesModel> tilesList = makeTilesValueList();
			responseObj.put("responseMsg", "Select one of the following : ");
			responseObj.put("responseData", tilesList);
			responseObj.put("responseType", "tiles");
		} else {
			List<String> valueList = new ArrayList<String>();
			valueList.add("fetchListData");
			valueList.add("fetchTilesData");
			responseObj.put("responseMsg", "Select one of the following : ");
			responseObj.put("responseData", valueList);
			responseObj.put("responseType", "buttons");

		}
		System.out.println("responseObj:"+responseObj.toString());
		return responseObj.toString();
	}

	private List<TilesModel> makeTilesValueList() {
		List<TilesModel> tilesList = new ArrayList<TilesModel>();
		TilesModel tile1 = makeTileValue(1);
		TilesModel tile2 = makeTileValue(2);
		TilesModel tile3 = makeTileValue(3);
		TilesModel tile4 = makeTileValue(4);
		TilesModel tile5 = makeTileValue(5);
		tilesList.add(tile1);
		tilesList.add(tile2);
		tilesList.add(tile3);
		tilesList.add(tile4);
		tilesList.add(tile5);
		return tilesList;
	}

	private TilesModel makeTileValue(int i) {
		TilesModel tile = new TilesModel();
		tile.setLabel("tileLabel" + String.valueOf(i));
		tile.setSpec1("Spec1_" + String.valueOf(i));
		tile.setSpec2("Spec2_" + String.valueOf(i));
		tile.setSpec3("Spec3_" + String.valueOf(i));
		return tile;
	}

}
